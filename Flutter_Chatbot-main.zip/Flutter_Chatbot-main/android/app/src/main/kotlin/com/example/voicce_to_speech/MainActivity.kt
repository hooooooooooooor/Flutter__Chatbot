package com.example.voicce_to_speech

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
