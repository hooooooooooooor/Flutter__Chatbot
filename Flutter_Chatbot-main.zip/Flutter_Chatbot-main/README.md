# Smart Methods Flutter ChatBot

A new Flutter voice to speech for the robot to talk to and talk back

## Getting Started

This project is a starting point for a Flutter application.

-------------------

## Setup

- This file will need you to setup flutter & dart : https://flutter.dev/docs/get-started/install
- Must Either use : Android Studio (Recommended) or Visual Studio Code
- Have a phone or install an emulator to run the application

-------------------

## Application Process

- This application will take voice command and process and make it into text
- This text will be processed by IBM Watson Assistance
- Replay will be taken from the assistance and be processed into speech to the user
